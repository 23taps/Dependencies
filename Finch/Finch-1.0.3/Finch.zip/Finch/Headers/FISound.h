@interface FISound : NSObject

@property(assign, readonly) BOOL isPlaying;

@property(assign, nonatomic) BOOL loop;
@property(assign, nonatomic) CGFloat gain;
@property(assign, nonatomic) CGFloat pitch;
@property(assign, readonly) NSTimeInterval duration;

- (instancetype) initWithPath: (NSString*) path maxPolyphony: (NSUInteger) voices error: (NSError**) error;
- (instancetype) initWithPath: (NSString*) path error: (NSError**) error;

- (void) play;
- (void) stop;

@end
