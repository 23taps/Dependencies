//
//  APNGKit.h
//  APNGKit
//
//  Created by Lilian Erhan on 28.07.2023.
//

#import <Foundation/Foundation.h>

//! Project version number for APNGKit.
FOUNDATION_EXPORT double APNGKitVersionNumber;

//! Project version string for APNGKit.
FOUNDATION_EXPORT const unsigned char APNGKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <APNGKit/PublicHeader.h>


