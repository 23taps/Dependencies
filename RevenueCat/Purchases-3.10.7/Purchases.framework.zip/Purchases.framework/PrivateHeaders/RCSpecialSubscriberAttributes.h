//
// Created by RevenueCat on 2/7/20.
// Copyright (c) 2020 Purchases. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define SPECIAL_ATTRIBUTE_EMAIL @"$email"
#define SPECIAL_ATTRIBUTE_PHONE_NUMBER @"$phoneNumber"
#define SPECIAL_ATTRIBUTE_DISPLAY_NAME @"$displayName"
#define SPECIAL_ATTRIBUTE_PUSH_TOKEN @"$apnsTokens"

#define SPECIAL_ATTRIBUTE_IDFA @"$idfa"
#define SPECIAL_ATTRIBUTE_IDFV @"$idfv"
#define SPECIAL_ATTRIBUTE_IP @"$ip"

#define SPECIAL_ATTRIBUTE_ADJUST_ID @"$adjustId"
#define SPECIAL_ATTRIBUTE_APPSFLYER_ID @"$appsflyerId"
#define SPECIAL_ATTRIBUTE_FB_ANON_ID @"$fbAnonId"
#define SPECIAL_ATTRIBUTE_MPARTICLE_ID @"$mparticleId"
#define SPECIAL_ATTRIBUTE_ONESIGNAL_ID @"$onesignalId"

#define SPECIAL_ATTRIBUTE_MEDIA_SOURCE @"$mediaSource"
#define SPECIAL_ATTRIBUTE_CAMPAIGN @"$campaign"
#define SPECIAL_ATTRIBUTE_AD_GROUP @"$adGroup"
#define SPECIAL_ATTRIBUTE_AD @"$ad"
#define SPECIAL_ATTRIBUTE_KEYWORD @"$keyword"
#define SPECIAL_ATTRIBUTE_CREATIVE @"$creative"

NS_ASSUME_NONNULL_END
