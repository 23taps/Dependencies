//
// Created by RevenueCat.
// Copyright (c) 2020 Purchases. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCAttributionTypeFactory.h"

NS_ASSUME_NONNULL_BEGIN

@interface RCAttributionTypeFactory (Protected)

- (NSString *)rot13:(NSString *)string;

@end

NS_ASSUME_NONNULL_END
