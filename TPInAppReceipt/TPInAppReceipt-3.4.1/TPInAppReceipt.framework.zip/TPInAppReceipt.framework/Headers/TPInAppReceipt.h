//
//  TPInAppReceipt.h
//  TPInAppReceipt
//
//  Created by Lilian Erhan on 06.05.2024.
//

#import <Foundation/Foundation.h>

//! Project version number for TPInAppReceipt.
FOUNDATION_EXPORT double TPInAppReceiptVersionNumber;

//! Project version string for TPInAppReceipt.
FOUNDATION_EXPORT const unsigned char TPInAppReceiptVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TPInAppReceipt/PublicHeader.h>


